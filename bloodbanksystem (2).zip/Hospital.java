/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bloodbanksystem;

public class Hospital extends User {
 
    
    public Hospital(String username, String password) {
        super(username, password);
      
     }
   
     
    public void hospitalOperation(){
          System.out.println("Hospital operation performed.");
    }
    

    
}